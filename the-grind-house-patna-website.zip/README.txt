# The Grind House - Website Package

This ZIP contains the complete production-ready HTML website for The Grind House (Patna).

## Files:
- `index.html`: The full responsive website with all sections, menu, table reservation, and map.
- `CLIENT_PITCH_PROPOSAL.md`: A complete business proposal you can pitch to the cafe owner.

## How to test locally:
Double click `index.html` to open it in Chrome, Safari, or Firefox.

## How to deploy:
Drag and drop this folder onto https://app.netlify.com/drop or upload to any hosting provider.
